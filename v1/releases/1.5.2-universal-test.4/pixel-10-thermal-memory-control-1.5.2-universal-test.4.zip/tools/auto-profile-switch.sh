#!/system/bin/sh
ID="pixel-10-pro-xl-thermal-fix"
MODDIR="${MODDIR:-$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)}"
G="$MODDIR/guard"
L="$G/auto-profile-switch.log"
STATE="$MODDIR/install-state.txt"
CFG="/data/adb/$ID/config.env"
mkdir -p "$G"
log(){ echo "$(date -Is 2>/dev/null || date) $*" >> "$L"; }
getcfg(){ [ -r "$CFG" ] && grep -E "^$1=" "$CFG" 2>/dev/null | tail -n1 | sed "s/^$1=//" | tr -d '\r'; }
getstate(){ [ -r "$STATE" ] && grep -E "^$1=" "$STATE" 2>/dev/null | tail -n1 | sed "s/^$1=//" | tr -d '\r'; }
sha_file(){ sha256sum "$1" 2>/dev/null | awk '{print $1}'; }
prop(){ getprop "$1" 2>/dev/null || true; }

AUTO="$(getcfg AUTO_PROFILE_SWITCH)"
[ -n "$AUTO" ] || AUTO=1
case "$AUTO" in 1|yes|true|on|enabled) ;; *) log "AUTO_SWITCH_SKIP reason=config_disabled value=$AUTO"; echo config_disabled > "$G/auto_profile_switch_state"; exit 0 ;; esac

DEVICE="$(prop ro.product.device)"
ANDROID="$(prop ro.build.version.release)"
SDK="$(prop ro.build.version.sdk)"
BUILD_ID="$(prop ro.build.id)"
FINGERPRINT="$(prop ro.build.fingerprint)"
INCREMENTAL="$(prop ro.build.version.incremental)"

A16_BUILD="CP1A.260505.005"
A17_CP31_BUILD="CP31.260618.005"
A17_CP31_INC="pending_exact_incremental"
A17_CP31_FP="pending_exact_fingerprint"
A17_CP31_QPR1B4_BUILD="CP31.260522.006"
A17_CP31_QPR1B4_INC="15591510"
A17_CP31_QPR1B4_FP="google/mustang_beta/mustang:CinnamonBun/CP31.260522.006/15591510:user/release-keys"
A17_CP21_BUILD="CP21.260330.011"
A17_STABLE_BUILD="CP2A.260605.012"
A17_STABLE_INC="15430684"

PROFILE=""
PROFILE_STATE=""
BUILD_STATE=""
GUARD=""
SOURCE_BUILD=""
SOURCE_INC=""

case "$ANDROID" in
  16|16.*)
    case "$DEVICE" in mustang|blazer|frankel|rango) ;; *) GUARD="unsupported_android16_device_$DEVICE" ;; esac
    if [ -z "$GUARD" ]; then
      PROFILE="$DEVICE"
      PROFILE_STATE="auto_android16_${DEVICE}_major_guard"
      BUILD_STATE="android16_${DEVICE}_${BUILD_ID}_${INCREMENTAL}_major_guard_auto_switch"
      SOURCE_BUILD="$A16_BUILD"
      SOURCE_INC="not_applicable"
    fi
  ;;
  17|17.*)
    case "$DEVICE" in
      mustang)
        case "$BUILD_ID" in
          CP31.*) PROFILE="mustang-android17-cp31"; PROFILE_STATE="auto_android17_cp31_mustang_major_guard"; BUILD_STATE="android17_mustang_${BUILD_ID}_${INCREMENTAL}_major_guard_auto_switch_using_cp31_profile"; SOURCE_BUILD="$A17_CP31_BUILD"; SOURCE_INC="$A17_CP31_INC" ;;
          CP21.*) PROFILE="mustang-android17-cp21"; PROFILE_STATE="auto_android17_cp21_mustang_major_guard"; BUILD_STATE="android17_mustang_${BUILD_ID}_${INCREMENTAL}_major_guard_auto_switch_using_cp21_profile"; SOURCE_BUILD="$A17_CP21_BUILD"; SOURCE_INC="$INCREMENTAL" ;;
          *) PROFILE="mustang-android17-stable-cp2a-260605012"; PROFILE_STATE="auto_android17_stable_mustang_major_guard"; BUILD_STATE="android17_mustang_${BUILD_ID}_${INCREMENTAL}_major_guard_auto_switch_using_cp2a_profile"; SOURCE_BUILD="$A17_STABLE_BUILD"; SOURCE_INC="$A17_STABLE_INC" ;;
        esac ;;
      frankel|blazer|rango)
        case "$BUILD_ID" in
          CP21.*) PROFILE="${DEVICE}-android17-cp21"; PROFILE_STATE="auto_android17_cp21_${DEVICE}_major_guard"; BUILD_STATE="android17_${DEVICE}_${BUILD_ID}_${INCREMENTAL}_major_guard_auto_switch_using_cp21_profile"; SOURCE_BUILD="$A17_CP21_BUILD"; SOURCE_INC="$INCREMENTAL" ;;
          *) PROFILE="${DEVICE}-android17-stable-cp2a-260605012"; PROFILE_STATE="auto_android17_stable_${DEVICE}_major_guard"; BUILD_STATE="android17_${DEVICE}_${BUILD_ID}_${INCREMENTAL}_major_guard_auto_switch_using_cp2a_profile"; SOURCE_BUILD="$A17_STABLE_BUILD"; SOURCE_INC="$A17_STABLE_INC" ;;
        esac ;;
      *) GUARD="unsupported_android17_device_$DEVICE" ;;
    esac
  ;;
  *) GUARD="unsupported_android_$ANDROID" ;;
esac


if [ -n "$GUARD" ] || [ -z "$PROFILE" ]; then
  echo "unsupported_or_incompatible_build" > "$G/auto_profile_switch_state"
  echo "$GUARD" > "$G/auto_profile_switch_reason"
  echo PROFILE_STALE_AFTER_OTA=yes > "$G/profile_stale_after_ota"
  echo REINSTALL_REQUIRED=yes > "$G/reinstall_required"
  touch "$MODDIR/skip_mount"
  log "AUTO_SWITCH_BLOCK reason=$GUARD action=set_skip_mount device=$DEVICE android=$ANDROID build=$BUILD_ID incremental=$INCREMENTAL"
  exit 0
fi

# Test9 profile matrix chooses exact device/build base before preserving outdoor variant.
[ -s "$MODDIR/tools/profile-matrix-test9.sh" ] && . "$MODDIR/tools/profile-matrix-test9.sh"
if command -v profile_matrix_base >/dev/null 2>&1; then
  MATRIX_PROFILE="$(profile_matrix_base "$DEVICE" "$BUILD_ID" 2>/dev/null || true)"
  if [ -n "$MATRIX_PROFILE" ] && [ -s "$MODDIR/profiles/$MATRIX_PROFILE/system/vendor/etc/thermal_info_config_throttling.json" ]; then
    PROFILE="$MATRIX_PROFILE"
    case "$BUILD_ID" in
      CP31.*|cp31.*)
        PROFILE_STATE="auto_android17_cp31_${DEVICE}_matrix_current_alias"
        BUILD_STATE="android17_${DEVICE}_${BUILD_ID}_${INCREMENTAL}_matrix_current_alias_auto_switch"
        SOURCE_BUILD="$A17_CP31_BUILD"
        SOURCE_INC="$A17_CP31_INC"
      ;;
    esac
    log "AUTO_SWITCH_INFO reason=test9_matrix_profile profile=$PROFILE"
  fi
fi

BASE_PROFILE="$PROFILE"
THERMAL_OUTDOOR_PROFILE="$(getcfg THERMAL_OUTDOOR_PROFILE)"
case "$THERMAL_OUTDOOR_PROFILE" in
  outdoor-safe|outdoor-plus|outdoor-extended)
    OUTDOOR_PROFILE="${BASE_PROFILE}-${THERMAL_OUTDOOR_PROFILE}"
    OUTDOOR_PROFILE_DIR="$MODDIR/profiles/$OUTDOOR_PROFILE/system/vendor/etc"
    if [ -s "$OUTDOOR_PROFILE_DIR/thermal_info_config_throttling.json" ] && [ -s "$OUTDOOR_PROFILE_DIR/thermal_info_config.json" ] && [ -s "$OUTDOOR_PROFILE_DIR/thermal_info_config_charge.json" ]; then
      PROFILE="$OUTDOOR_PROFILE"
      case "$THERMAL_OUTDOOR_PROFILE" in
        outdoor-safe)
          PROFILE_STATE="${PROFILE_STATE}_outdoor_safe_test25"
          BUILD_STATE="${BUILD_STATE}_outdoor_safe_test25"
        ;;
        outdoor-plus)
          PROFILE_STATE="${PROFILE_STATE}_outdoor_plus_test25"
          BUILD_STATE="${BUILD_STATE}_outdoor_plus_test25"
        ;;
        outdoor-extended)
          PROFILE_STATE="${PROFILE_STATE}_outdoor_extended_test25"
          BUILD_STATE="${BUILD_STATE}_outdoor_extended_test25"
        ;;
      esac
    else
      log "AUTO_SWITCH_WARN reason=selected_outdoor_profile_missing base=$BASE_PROFILE outdoor=$THERMAL_OUTDOOR_PROFILE action=keep_base"
    fi
  ;;
esac

PROFILE_DIR="$MODDIR/profiles/$PROFILE/system/vendor/etc"
ACTIVE_DIR="$MODDIR/system/vendor/etc"
for f in thermal_info_config_throttling.json thermal_info_config.json thermal_info_config_charge.json; do
  if [ ! -s "$PROFILE_DIR/$f" ]; then
    echo missing_profile_file > "$G/auto_profile_switch_state"
    echo "$PROFILE/$f" > "$G/auto_profile_switch_reason"
    touch "$MODDIR/skip_mount"
    log "AUTO_SWITCH_BLOCK reason=missing_profile_file file=$PROFILE/$f action=set_skip_mount"
    exit 0
  fi
done

if [ -r /vendor/etc/thermal_info_config_throttling.json ]; then
  grep -q "VIRTUAL-SKIN" /vendor/etc/thermal_info_config_throttling.json 2>/dev/null || log "AUTO_SWITCH_WARN reason=stock_marker_missing_or_overlay_already_active"
else
  log "AUTO_SWITCH_WARN reason=stock_thermal_unreadable"
fi

OLD_PROFILE="$(getstate profile)"
OLD_ANDROID="$(getstate android)"
OLD_BUILD="$(getstate build_id)"
OLD_INC="$(getstate incremental)"
NEED=0
[ "$OLD_PROFILE" = "$PROFILE" ] || NEED=1
[ "$OLD_ANDROID" = "$ANDROID" ] || NEED=1
[ "$OLD_BUILD" = "$BUILD_ID" ] || NEED=1
[ "$OLD_INC" = "$INCREMENTAL" ] || NEED=1

for f in thermal_info_config_throttling.json thermal_info_config.json thermal_info_config_charge.json; do
  a="$(sha_file "$ACTIVE_DIR/$f")"
  b="$(sha_file "$PROFILE_DIR/$f")"
  [ -n "$a" ] && [ "$a" = "$b" ] || NEED=1
done

if [ "$NEED" = 0 ]; then
  echo current_profile_valid > "$G/auto_profile_switch_state"
  echo "$PROFILE" > "$G/selected_profile"
  log "AUTO_SWITCH_PASS reason=current_profile_valid profile=$PROFILE device=$DEVICE android=$ANDROID build=$BUILD_ID incremental=$INCREMENTAL"
  exit 0
fi

mkdir -p "$ACTIVE_DIR"
for f in thermal_info_config_throttling.json thermal_info_config.json thermal_info_config_charge.json; do
  if [ -e "$ACTIVE_DIR/$f" ]; then
    cat "$PROFILE_DIR/$f" > "$ACTIVE_DIR/$f" || { log "AUTO_SWITCH_BLOCK reason=write_failed file=$f"; touch "$MODDIR/skip_mount"; exit 0; }
  else
    cp -fp "$PROFILE_DIR/$f" "$ACTIVE_DIR/$f" || { log "AUTO_SWITCH_BLOCK reason=copy_failed file=$f"; touch "$MODDIR/skip_mount"; exit 0; }
  fi
  chmod 0644 "$ACTIVE_DIR/$f" 2>/dev/null || true
done

rm -f "$MODDIR/skip_mount" "$G/disabled_reason" "$G/profile_stale_after_ota" "$G/reinstall_required" 2>/dev/null || true
{
  echo "module_id=$ID"
  echo "module_version=$(grep -E '^version=' "$MODDIR/module.prop" 2>/dev/null | head -n1 | sed 's/^version=//')"
  echo "module_version_code=$(grep -E '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | head -n1 | sed 's/^versionCode=//')"
  echo "device=$DEVICE"
  echo "android=$ANDROID"
  echo "android_sdk=$SDK"
  echo "build_id=$BUILD_ID"
  echo "incremental=$INCREMENTAL"
  echo "profile=$PROFILE"
  echo "profile_state=$PROFILE_STATE"
  echo "build_state=$BUILD_STATE"
  echo "build_guard_mode=android_major_only"
  echo "profile_source_build=$SOURCE_BUILD"
  echo "profile_source_incremental=$SOURCE_INC"
  echo "auto_profile_switch=yes"
  echo "auto_profile_switch_state=materialized"
  echo "auto_profile_switch_at=$(date -Is 2>/dev/null || date)"
  echo "profile_materialized=yes"
  echo "expected_thermal_files=3"
  echo "update_json_channel=stable_update_json_1.5.1-universal.1"
} > "$STATE"
echo materialized > "$G/auto_profile_switch_state"
echo "$PROFILE" > "$G/selected_profile"
log "AUTO_SWITCH_DONE old_profile=${OLD_PROFILE:-none} new_profile=$PROFILE old_android=${OLD_ANDROID:-none} new_android=$ANDROID old_build=${OLD_BUILD:-none} new_build=$BUILD_ID old_incremental=${OLD_INC:-none} new_incremental=$INCREMENTAL"
exit 0
